#!/usr/bin/env bash

sketchybar -m --set $NAME label="$(date '+%d/%m %H:%M')"

